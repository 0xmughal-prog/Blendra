'use client';

import { useState } from 'react';
import { useWriteContract, useWaitForTransactionReceipt, useReadContract } from 'wagmi';
import { CONTRACTS } from '@/lib/config';
import { MINTER_ABI } from '@/abi/minter';
import { parseUnits } from 'viem';

export function AdminActions() {
  const [tvlCapInput, setTvlCapInput] = useState('');
  const [minReserveInput, setMinReserveInput] = useState('');
  const [fundAmount, setFundAmount] = useState('');

  const { data: paused } = useReadContract({
    address: CONTRACTS.MINTER,
    abi: MINTER_ABI,
    functionName: 'paused',
  });

  const { writeContract, data: hash, isPending } = useWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash });

  const handlePause = () => {
    writeContract({
      address: CONTRACTS.MINTER,
      abi: MINTER_ABI,
      functionName: 'pause',
    });
  };

  const handleUnpause = () => {
    writeContract({
      address: CONTRACTS.MINTER,
      abi: MINTER_ABI,
      functionName: 'unpause',
    });
  };

  const handleSetTVLCap = () => {
    if (!tvlCapInput) return;
    const amount = parseUnits(tvlCapInput, 6);
    writeContract({
      address: CONTRACTS.MINTER,
      abi: MINTER_ABI,
      functionName: 'setTVLCap',
      args: [amount],
    });
  };

  const handleSetMinReserve = () => {
    if (!minReserveInput) return;
    const amount = parseUnits(minReserveInput, 6);
    writeContract({
      address: CONTRACTS.MINTER,
      abi: MINTER_ABI,
      functionName: 'setMinReserveBalance',
      args: [amount],
    });
  };

  const handleFundReserve = () => {
    if (!fundAmount) return;
    const amount = parseUnits(fundAmount, 6);
    writeContract({
      address: CONTRACTS.MINTER,
      abi: MINTER_ABI,
      functionName: 'fundReserve',
      args: [amount],
    });
  };

  const handleRebalancePerp = () => {
    writeContract({
      address: CONTRACTS.MINTER,
      abi: MINTER_ABI,
      functionName: 'rebalancePerp',
    });
  };

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
      <h3 className="text-xl font-bold text-white mb-4">Admin Actions</h3>

      <div className="space-y-4">
        {/* Pause/Unpause */}
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Protocol Control</label>
          <button
            onClick={paused ? handleUnpause : handlePause}
            disabled={isPending || isConfirming}
            className={`w-full px-4 py-3 rounded-lg font-bold transition-colors ${
              paused
                ? 'bg-green-600 hover:bg-green-700 text-white'
                : 'bg-red-600 hover:bg-red-700 text-white'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            {isPending || isConfirming
              ? 'Processing...'
              : paused
              ? '▶️ Unpause Protocol'
              : '⏸ Pause Protocol'}
          </button>
        </div>

        {/* Set TVL Cap */}
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Set TVL Cap (USD)</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={tvlCapInput}
              onChange={(e) => setTvlCapInput(e.target.value)}
              placeholder="5000"
              className="flex-1 px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-primary-500"
            />
            <button
              onClick={handleSetTVLCap}
              disabled={!tvlCapInput || isPending || isConfirming}
              className="px-6 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Set
            </button>
          </div>
        </div>

        {/* Set Min Reserve */}
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Set Min Reserve (USD)</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={minReserveInput}
              onChange={(e) => setMinReserveInput(e.target.value)}
              placeholder="100"
              className="flex-1 px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-primary-500"
            />
            <button
              onClick={handleSetMinReserve}
              disabled={!minReserveInput || isPending || isConfirming}
              className="px-6 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Set
            </button>
          </div>
        </div>

        {/* Fund Reserve */}
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Fund Reserve (USDC)</label>
          <div className="flex gap-2">
            <input
              type="number"
              value={fundAmount}
              onChange={(e) => setFundAmount(e.target.value)}
              placeholder="500"
              className="flex-1 px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-primary-500"
            />
            <button
              onClick={handleFundReserve}
              disabled={!fundAmount || isPending || isConfirming}
              className="px-6 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Fund
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Note: Approve USDC first if needed
          </p>
        </div>

        {/* Rebalance Perp */}
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Perp Management</label>
          <button
            onClick={handleRebalancePerp}
            disabled={isPending || isConfirming}
            className="w-full px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-bold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isPending || isConfirming ? 'Processing...' : '🔄 Rebalance Perp Position'}
          </button>
        </div>

        {/* Transaction Status */}
        {(isPending || isConfirming || isSuccess) && (
          <div className="mt-4 p-3 rounded-lg bg-gray-700/50 border border-gray-600">
            {isPending && (
              <p className="text-sm text-yellow-400">⏳ Waiting for wallet confirmation...</p>
            )}
            {isConfirming && (
              <p className="text-sm text-blue-400">⏳ Transaction confirming...</p>
            )}
            {isSuccess && (
              <p className="text-sm text-green-400">✅ Transaction confirmed!</p>
            )}
            {hash && (
              <a
                href={`https://arbiscan.io/tx/${hash}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-primary-400 hover:text-primary-300 block mt-1"
              >
                View on Arbiscan →
              </a>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
